### Hexlet tests and linter status:
[![Actions Status](https://github.com/aiakupov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/aiakupov/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/324ffcbe74630bc5e144/maintainability)](https://codeclimate.com/github/aiakupov/python-project-49/maintainability)